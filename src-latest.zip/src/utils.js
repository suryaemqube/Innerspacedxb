export function dashCase(inputString) {
    return inputString.toLowerCase().replace(/ /g, '-');
}